let projects = JSON.parse(localStorage.getItem("projects")) || [];

function save() {
  localStorage.setItem("projects", JSON.stringify(projects));
}

function addProject() {
  const name = document.getElementById("projectName").value;
  if (!name) return alert("Enter project name");

  projects.push({ name, tasks: [] });
  document.getElementById("projectName").value = "";
  save();
  displayProjects();
}

function addTask(pIndex) {
  const taskName = prompt("Task name:");
  const deadline = prompt("Deadline (YYYY-MM-DD):");
  if (!taskName) return;

  projects[pIndex].tasks.push({
    name: taskName,
    deadline,
    completed: false
  });
  save();
  displayProjects();
}

function toggleTask(pIndex, tIndex) {
  projects[pIndex].tasks[tIndex].completed =
    !projects[pIndex].tasks[tIndex].completed;
  save();
  displayProjects();
}

function displayProjects() {
  const container = document.getElementById("projects");
  container.innerHTML = "";

  projects.forEach((project, pIndex) => {
    let html = `
      <div class="project">
        <h3>${project.name}</h3>
        <button onclick="addTask(${pIndex})">Add Task</button>
    `;

    project.tasks.forEach((task, tIndex) => {
      html += `
        <div class="task ${task.completed ? "completed" : ""}">
          <span>
            ${task.name} <br>
            📅 ${task.deadline || "No deadline"}
          </span>
          <button onclick="toggleTask(${pIndex}, ${tIndex})">
            ${task.completed ? "Undo" : "Done"}
          </button>
        </div>
      `;
    });

    html += `</div>`;
    container.innerHTML += html;
  });
}

displayProjects();
