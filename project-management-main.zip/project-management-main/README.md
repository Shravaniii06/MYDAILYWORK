📋 Project Management Tool

A simple Project Management Tool web app to create and manage projects. The site lets you add, view, and organize projects from your browser.

Live Demo: https://shravaniii06.github.io/project-management/

🚀 Features

Create Projects

Display Project List

💡 This tool is ideal for learning basic project CRUD (Create, Read, Update, Delete) operations in web development.

🧠 About

This is a lightweight web‑based project management utility to help users organize and keep track of projects. You can add project entries and view them in a list.


🛠️ How It Works

Visit the live URL above.

In the Create Project section, enter project details.

Click Add Project to save it.

Your project will appear in the project list.

📁 Technologies Used

HTML

CSS

JavaScript


🧩 Project Structure
📦 project-management
 ┣ index.html
 ┣ style.css
 ┣ script.js
 ┗ README.md
