# Online Quiz Maker

A web-based quiz maker built using HTML, CSS, and JavaScript.

## Features
- Create quizzes
- Take quizzes one question at a time
- Show final score
- Mobile responsive
- Uses localStorage (no backend)


## Live Demo
https://shravaniii06.github.io/online-quiz-maker/


## Tech Stack
HTML, CSS, JavaScript
