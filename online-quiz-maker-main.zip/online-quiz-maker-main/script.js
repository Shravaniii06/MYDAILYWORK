// STORAGE
let quizzes = JSON.parse(localStorage.getItem("quizzes")) || [];
let currentQuiz = [];
let currentQ = 0;
let score = 0;

// ✅ ADD QUESTION
function addQuestion() {
  const q = document.getElementById("question").value;
  const options = [
    opt1.value,
    opt2.value,
    opt3.value,
    opt4.value
  ];
  const ans = document.getElementById("answer").value;

  if (!q || options.includes("") || !ans) {
    alert("Fill all fields");
    return;
  }

  currentQuiz.push({ question: q, options, answer: ans });

  document.querySelectorAll("input").forEach(i => i.value = "");
  alert("Question Added ✅");
}

// ✅ SAVE QUIZ (FIXED)
function saveQuiz() {
  if (currentQuiz.length === 0) {
    alert("Add at least one question!");
    return;
  }

  quizzes.push(currentQuiz);
  localStorage.setItem("quizzes", JSON.stringify(quizzes));

  alert("Quiz Saved Successfully ✅");
  window.location.href = "index.html";
}

// ✅ SHOW QUIZ LIST
if (document.getElementById("quizList")) {
  const list = document.getElementById("quizList");
  list.innerHTML = "";

  quizzes.forEach((quiz, index) => {
    const li = document.createElement("li");
    li.innerHTML = `<button onclick="startQuiz(${index})">
      Start Quiz ${index + 1}
    </button>`;
    list.appendChild(li);
  });
}

// ✅ START QUIZ
function startQuiz(i) {
  localStorage.setItem("quizIndex", i);
  window.location.href = "quiz.html";
}

// ✅ LOAD QUIZ
if (document.getElementById("qText")) {
  const quiz = quizzes[localStorage.getItem("quizIndex")];
  showQuestion();

  function showQuestion() {
    if (currentQ >= quiz.length) {
      localStorage.setItem("score", score);
      window.location.href = "result.html";
      return;
    }

    document.getElementById("qText").innerText =
      quiz[currentQ].question;

    const box = document.getElementById("options");
    box.innerHTML = "";

    quiz[currentQ].options.forEach(opt => {
      const btn = document.createElement("button");
      btn.innerText = opt;
      btn.onclick = () => checkAnswer(opt);
      box.appendChild(btn);
    });
  }

  function checkAnswer(opt) {
    if (opt === quiz[currentQ].answer) score++;
    currentQ++;
    showQuestion();
  }

  window.nextQuestion = () => showQuestion();
}

// ✅ RESULT
if (document.getElementById("score")) {
  document.getElementById("score").innerText =
    "Your Score: " + localStorage.getItem("score");
}